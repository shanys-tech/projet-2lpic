# Projet Infrastructure Linux

## Pour recréer l'infrastructure

1. Créer 3 VMs Ubuntu Server 22.04
2. Appliquer les configurations réseau (dossier configs/)
3. Installer les paquets : openssh-server, bind9, postfix, mailutils
4. Copier les scripts (dossier scripts/) sur srv-externe
5. Configurer les clés SSH (ssh-keygen + ssh-copy-id)
6. Démarrer cron avec les lignes fournies dans la justification

## Adresses IP utilisées dans la démo
- srv-externe : 192.168.64.11
- srv-interne : 192.168.64.13
- poste-inspecteur : 192.168.64.12

## Serveur DNS
- Domaine : grestin.local
- Serveur : srv-interne (192.168.64.13)