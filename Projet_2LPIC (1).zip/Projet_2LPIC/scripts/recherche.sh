#!/bin/bash
SEARCH_DIR="/home/patrice05/storage"
LOG_FILE="/home/patrice05/logs/recherche.log"

read -p "Entrez l'ID (nom du fichier) à rechercher: " file_id
if [ -z "$file_id" ]; then
    echo "ID invalide"
    exit 1
fi

found=0
for dir in pending accepted rejected; do
    if [ -f "$SEARCH_DIR/$dir/$file_id" ]; then
        echo "✅ Fichier trouvé dans: $dir"
        ls -lh "$SEARCH_DIR/$dir/$file_id"
        if [[ "$file_id" == *.zip ]]; then
            temp_dir="/tmp/search_$$"
            mkdir -p $temp_dir
            unzip -q "$SEARCH_DIR/$dir/$file_id" -d $temp_dir
            txt_count=$(find $temp_dir -name "*.txt" | wc -l)
            pdf_count=$(find $temp_dir -name "*.pdf" | wc -l)
            echo "📄 Contient: $txt_count txt, $pdf_count pdf"
            rm -rf $temp_dir
        fi
        echo "$(date): $file_id trouvé dans $dir" >> $LOG_FILE
        found=1
        break
    fi
done

if [ $found -eq 0 ]; then
    echo "❌ Fichier non trouvé"
    echo "$(date): $file_id non trouvé" >> $LOG_FILE
fi
