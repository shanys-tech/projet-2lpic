#!/bin/bash
UPLOAD_DIR="/home/patrice05/upload"
PENDING_DIR="/home/patrice05/pending"
REJECTED_DIR="/home/patrice05/rejected"
LOG_FILE="/home/patrice05/logs/nettoyage.log"

echo "$(date): Début du nettoyage" >> $LOG_FILE

for zipfile in $UPLOAD_DIR/*.zip; do
    if [ -f "$zipfile" ]; then
        filename=$(basename "$zipfile")
        temp_dir="/tmp/extract_$$"
        mkdir -p $temp_dir
        unzip -q "$zipfile" -d $temp_dir
        txt_count=$(find $temp_dir -name "*.txt" | wc -l)
        pdf_count=$(find $temp_dir -name "*.pdf" | wc -l)
        if [ $txt_count -gt 0 ] && [ $pdf_count -gt 0 ]; then
            mv "$zipfile" "$PENDING_DIR/$filename"
            echo "$(date): $filename -> ACCEPTÉ" >> $LOG_FILE
        else
            mv "$zipfile" "$REJECTED_DIR/$filename"
            echo "$(date): $filename -> REJETÉ" >> $LOG_FILE
        fi
        rm -rf $temp_dir
    fi
done

echo "$(date): Fin du nettoyage" >> $LOG_FILE
