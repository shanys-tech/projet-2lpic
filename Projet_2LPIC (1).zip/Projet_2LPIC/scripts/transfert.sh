#!/bin/bash
PENDING_DIR="/home/patrice05/pending"
STORAGE_SERVER="patrice05@192.168.64.13"
STORAGE_PATH="/home/patrice05/storage/pending"
LOG_FILE="/home/patrice05/logs/transfert.log"

echo "$(date): Début du transfert" >> $LOG_FILE

for file in $PENDING_DIR/*.zip; do
    if [ -f "$file" ]; then
        filename=$(basename "$file")
        scp "$file" "$STORAGE_SERVER:$STORAGE_PATH/"
        if [ $? -eq 0 ]; then
            rm "$file"
            echo "$(date): $filename -> TRANSFÉRÉ" >> $LOG_FILE
            echo "Fichier $filename transféré" | mail -s "Transfert réussi" patrice05@localhost
        else
            echo "$(date): $filename -> ÉCHEC transfert" >> $LOG_FILE
        fi
    fi
done

echo "$(date): Fin du transfert" >> $LOG_FILE
