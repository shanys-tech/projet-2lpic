#!/bin/bash
STORAGE_SERVER="patrice05@192.168.64.13"
STORAGE_PENDING="/home/patrice05/storage/pending"
STORAGE_ACCEPTED="/home/patrice05/storage/accepted"
STORAGE_REJECTED="/home/patrice05/storage/rejected"

echo "=== Fichiers en attente ==="
ssh $STORAGE_SERVER "ls -la $STORAGE_PENDING/*.zip 2>/dev/null" | awk '{print $9}' | grep -v "^$" | while read line; do basename "$line"; done

read -p "Entrez le nom du fichier à traiter: " filename
if [ -z "$filename" ]; then
    echo "Nom invalide"
    exit 1
fi

read -p "Accepter (1) ou Refuser (2) ? " choix
case $choix in
    1)
        ssh $STORAGE_SERVER "mv $STORAGE_PENDING/$filename $STORAGE_ACCEPTED/"
        echo "✅ Fichier ACCEPTÉ"
        echo "Fichier $filename accepté" | mail -s "Décision: Accepté" patrice05@localhost
        ;;
    2)
        ssh $STORAGE_SERVER "mv $STORAGE_PENDING/$filename $STORAGE_REJECTED/"
        echo "❌ Fichier REJETÉ"
        echo "Fichier $filename rejeté" | mail -s "Décision: Rejeté" patrice05@localhost
        ;;
    *)
        echo "Choix invalide"
        ;;
esac
