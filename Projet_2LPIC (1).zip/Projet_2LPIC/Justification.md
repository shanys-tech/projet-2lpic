# Justification des choix techniques

## 1. Choix de l’OS et de l’architecture

- **Ubuntu Server 22.04 LTS** : distribution stable, légère, sans interface graphique inutile, parfait pour des serveurs en ligne de commande.
- **Trois machines virtuelles distinctes** : isolation des rôles – un serveur frontal (upload/tri), un serveur interne (stockage/traitement), un poste inspecteur. Conforme au cahier des charges.
- **UTM sur macOS** : environnement de virtualisation simple et gratuit, adapté à la démonstration.

## 2. Configuration réseau

- **Mode Shared Network (DHCP)** : simplifie la configuration en environnement de laboratoire. Les adresses IP sont automatiquement attribuées et restent stables (baux longs). Après ajustement des adresses MAC des clones, chaque VM possède une IP unique.
- **IPs dynamiques** : pas de configuration statique complexe ; les scripts utilisent les IP effectives (ex. `192.168.64.11`, `.12`, `.13`). Cela n’affecte pas la démonstration.
- **SSH activé sur toutes les VMs** : permet les connexions sécurisées et les transferts `scp` automatisés.

## 3. Serveur DNS (résolution de noms)

- **Bind9** installé sur `srv-interne` (192.168.64.13) et configuré pour le domaine `grestin.local`.
- Fichier de zone `db.grestin.local` définissant les enregistrements A :
  - `srv-externe.grestin.local` → 192.168.64.11
  - `srv-interne.grestin.local` → 192.168.64.13
  - `poste-inspecteur.grestin.local` → 192.168.64.12
- Sur les machines clientes (`srv-externe` et `poste-inspecteur`), le service `systemd-resolved` a été désactivé et remplacé par un fichier `/etc/resolv.conf` statique pointant vers le serveur DNS `192.168.64.13`. Cela évite les erreurs `SERVFAIL` et garantit une résolution fiable.
- Le serveur DNS permet d’utiliser des noms de domaine plutôt que des adresses IP brutes, améliorant la lisibilité et l’évolutivité.

## 4. Sécurité

- **Authentification par clé SSH** : génération d’une paire de clés sur `srv-externe` et copie vers les deux autres machines. Les scripts peuvent ainsi lancer `scp` et `ssh` sans intervention humaine (pas de mot de passe en clair).
- **Postfix en mode local** : les notifications mail restent sur chaque VM (pas d’exposition externe). Simple, sans risque, suffisant pour une preuve de concept.

### Pare-feu (UFW) sur le poste inspecteur

Conformément aux exigences de sécurité du gouvernement, un pare-feu a été activé sur le poste inspecteur (`poste-inspecteur`) avec les règles suivantes :

- **Politique par défaut** : refus de tout trafic entrant et sortant (`default deny incoming/outgoing`)
- **Autorisations entrantes** :
  - SSH (port 22) – pour l’administration à distance
- **Autorisations sortantes** :
  - DNS (port 53 UDP) – pour la résolution de noms vers le serveur DNS interne
  - HTTP/HTTPS (ports 80 et 443 TCP) – pour un accès limité au site web du gouvernement
  - Connexion vers le serveur interne `srv-interne` (192.168.64.13) – pour consulter et traiter les dossiers d’immigration

Cette configuration garantit que le poste inspecteur ne peut communiquer qu’avec les services strictement nécessaires, limitant ainsi la surface d’attaque et respectant la contrainte d’un accès Internet restreint.

```bash
# Règles UFW appliquées
sudo ufw default deny incoming
sudo ufw default deny outgoing
sudo ufw allow ssh
sudo ufw allow out 53/udp
sudo ufw allow out 80/tcp
sudo ufw allow out 443/tcp
sudo ufw allow out to 192.168.64.13

## 5. Gestion des fichiers et scripts

### Nettoyage (`nettoyage.sh`)
- Vérifie la présence **obligatoire** d’au moins un fichier `.txt` et d’au moins un fichier `.pdf` dans l’archive `.zip`.
- Trie : valide → `pending/`, invalide → `rejected/`.
- Journalisation (`logs/nettoyage.log`) pour traçabilité.
- Critères facilement modifiables (ajout d’une liste blanche, regex sur le nom, etc.).

### Transfert (`transfert.sh`)
- Copie les archives de `pending/` vers `storage/pending/` du serveur interne via `scp`.
- Supprime le fichier local après succès.
- Envoie un email à l’inspecteur (sujet : "Transfert réussi").
- Logs des succès/échecs.

### Inspection (`inspecteur.sh` sur poste-inspecteur)
- Se connecte en SSH au serveur interne.
- Liste les fichiers en attente (`storage/pending/`).
- Permet à l’inspecteur d’accepter (1) ou refuser (2).
- Déplace le fichier vers `accepted/` ou `rejected/` sur le serveur interne.
- Envoie un email de décision.

### Recherche (`recherche.sh` sur serveur interne)
- Parcourt `pending/`, `accepted/`, `rejected/`.
- Affiche l’emplacement, la taille, le nombre de `.txt` et `.pdf` contenus dans le `.zip`.
- Journalise chaque recherche.

## 6. Automatisation

- **Cron** sur `srv-externe` :
  - `* * * * *` → `nettoyage.sh` (toutes les minutes pour une démo réactive).
  - `*/2 * * * *` → `transfert.sh` (toutes les 2 minutes).
- Choix des fréquences : accélère la démonstration ; en production, on passerait à des intervalles plus longs (ex. 5 min ou déclenchement par `inotify`).

## 7. Notification mail

- **Postfix + mailutils** : installation simple, configuration par défaut (mode "Site Internet").
- Les emails sont envoyés à l’utilisateur local `patrice05@localhost`. On peut les consulter avec la commande `mail`.
- Suffisant pour prouver le fonctionnement.

## 8. Points simplifiés ou non implémentés

| Fonction | Statut | Justification |
|----------|--------|----------------|
| RAID | Non fait | Non demandé explicitement dans la grille de ce projet, mais ajoutable en production (mdadm). |
| DNS | **Implémenté** | Serveur Bind9 sur `srv-interne` avec résolution des noms du domaine `grestin.local`. |
| Serveur DHCP dédié | Non fait | Le DHCP intégré d’UTM remplit le rôle. Un serveur DHCP autonome n’apporterait rien de plus ici. |
| Pare-feu avancé | Non fait | L’environnement est isolé (réseau virtuel). On peut activer `ufw` en 2 minutes si demandé. |

## 9. Conclusion

L’infrastructure remplit toutes les fonctionnalités obligatoires :
- Upload et tri des archives
- Transfert automatique vers un serveur interne
- Organisation en dossiers pending/accepted/rejected
- Notification par email
- Script d’inspection (accepter/refuser)
- Script de recherche par ID
- Configuration réseau (IPs fonctionnelles)
- **Serveur DNS** fonctionnel (Bind9)