# Schéma de l'infrastructure

## Architecture réseau et flux de données

![Image de l'architecture réseau](Architecture_réseau.png)

## Flux des données

| Étape | Description |

|-------|-------------|
| ① | Dépôt d’un `.zip` (`.txt` + `.pdf`) dans `upload/` de `srv-externe` |

| ② | `nettoyage.sh` (cron) vérifie et trie : valide → `pending/`, invalide → `rejected/` |

| ③ | `transfert.sh` (cron) envoie le fichier valide vers `storage/pending/` de `srv-interne` via SCP |

| ④ | L’inspecteur exécute `inspecteur.sh` sur `poste-inspecteur` : se connecte à `srv-interne`, liste les dossiers, accepte (→ `accepted/`) ou refuse (→ `rejected/`) |

| ⑤ | `recherche.sh` sur `srv-interne` permet de retrouver un dossier par son nom (ID) |

| ⑥ | Les mails de notification sont envoyés localement sur chaque VM (Postfix) |

## Récapitulatif des adresses IP

| Machine | IP |
|---------|----|
| srv-externe | 192.168.64.11 |
| srv-interne | 192.168.64.13 |
| poste-inspecteur | 192.168.64.12 |